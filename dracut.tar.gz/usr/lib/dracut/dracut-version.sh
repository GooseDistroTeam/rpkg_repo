#!/bin/sh
# shellcheck disable=SC2034
DRACUT_VERSION=056
